import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PdfOverlays } from './pdf-overlays';

describe('PdfOverlays', () => {
  let component: PdfOverlays;
  let fixture: ComponentFixture<PdfOverlays>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [PdfOverlays]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PdfOverlays);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
