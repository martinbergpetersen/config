import { Component, ElementRef, HostListener, Injector, afterNextRender, inject, signal, viewChild } from '@angular/core';
import { PDFDocument, RGB, StandardFonts, degrees, rgb } from 'pdf-lib';
import * as pdfjsLib from 'pdfjs-dist';

pdfjsLib.GlobalWorkerOptions.workerSrc = '/pdf.worker.min.mjs';

export interface StampPreset {
  label: string;
  cssColor: string;
  pdfColor: RGB;
}

export const STAMP_PRESETS: StampPreset[] = [
  { label: 'APPROVED', cssColor: '#1a8a3c', pdfColor: rgb(0.1, 0.54, 0.24) },
  { label: 'REJECTED', cssColor: '#c0392b', pdfColor: rgb(0.75, 0.22, 0.17) },
  { label: 'CONFIDENTIAL', cssColor: '#a35b00', pdfColor: rgb(0.64, 0.36, 0) },
  { label: 'DRAFT', cssColor: '#666', pdfColor: rgb(0.4, 0.4, 0.4) },
];

export interface SignaturePreset {
  label: string;
  path: string;
}

// Served from public/signatures/ (see angular.json assets glob), copied
// from the source files in signature/. Picking one adds that person's
// actual signature image — there's no draw-your-own option.
export const SIGNATURE_PRESETS: SignaturePreset[] = [
  { label: 'Frederik Waesterberg', path: '/signatures/Frederik_Waesterberg.gif' },
  { label: 'Gitte Gjede', path: '/signatures/Gitte_Gjede.gif' },
  { label: 'Magnus Karlsson', path: '/signatures/Magnus_Karlsson.gif' },
  { label: 'Hanne Lind', path: '/signatures/Hanne_Lind.gif' },
  { label: 'Katarzyna Bar', path: '/signatures/Katarzyna_Bar.gif' },
  { label: 'Sari Nuutinen', path: '/signatures/SariNuutinen.gif' },
  { label: 'Louise Frydenlund', path: '/signatures/Louise_Frydenlund.gif' },
];

// On-screen display cap (canvas-pixel space, i.e. already at `scale`) for a
// freshly-added signature — the source images vary in size, and without a
// cap a large one would land oversized. Still freely resizable afterward.
const SIGNATURE_MAX_INITIAL_WIDTH = 240;

// Rough visual offset used ONLY to position the editing <input> reasonably
// while typing (an <input> can't be baseline-aligned like SVG text can).
// It's purely cosmetic — item.top itself is the baseline, used directly and
// exactly by both the locked SVG preview and download(), so this constant
// being approximate never affects the exported result.
const APPROX_ASCENT_FOR_EDITING_INPUT = 0.7;

// Rotation conventions are opposite between the two coordinate systems:
// PDF y-axis points up (positive degrees = counter-clockwise), CSS y-axis
// points down (positive degrees = clockwise). Same magnitude, opposite sign,
// gives the same visual tilt on screen and in the exported PDF.
const STAMP_ROTATION_DEG = -20;

// Strikethrough is a fixed-thickness rule: unlike text/stamp it never grows
// "font size" wise, so this is a constant rather than a per-item field.
const STRIKETHROUGH_THICKNESS_PT = 1.5;

interface OverlayItem {
  id: number;
  left: number;
  top: number;
  kind: 'text' | 'signature' | 'checkbox' | 'stamp' | 'strikethrough';
  text: string;
  fontSize: number;
  imageDataUrl?: string;
  imgWidth?: number;
  imgHeight?: number;
  checked?: boolean;
  checkboxSize?: number;
  stampColor?: RGB;
  stampCssColor?: string;
  strikeWidth?: number;
}

// PDF libraries used here: pdf-lib builds the exported PDF (drawText,
// drawRectangle, drawLine, drawImage, embedPng, embedFont), and pdfjs-dist
// renders the loaded PDF's pages to canvas for the on-screen preview.
// package.json: "pdf-lib": "^1.17.1", "pdfjs-dist": "^6.2.108"
@Component({
  selector: 'app-pdf-overlays',
  imports: [],
  templateUrl: './pdf-overlays.html',
  styleUrl: './pdf-overlays.css',
})
export class PdfOverlays {
  private readonly canvasRef = viewChild<ElementRef<HTMLCanvasElement>>('pdfCanvas');
  private readonly injector = inject(Injector);

  protected readonly pageCount = signal(0);
  protected readonly currentPage = signal(1);
  protected readonly canvasWidth = signal(0);
  protected readonly canvasHeight = signal(0);

  protected readonly scale = 1.5;
  private fileBytes: Uint8Array | null = null;

  private readonly overlaysByPage = signal<Map<number, OverlayItem[]>>(new Map());
  protected readonly currentItems = signal<OverlayItem[]>([]);
  // the one item currently showing its editing chrome (drag handle, inputs,
  // remove button); every other item renders as plain, final-looking
  // content. Clicking anywhere outside it applies/locks it; double-clicking
  // a locked item's content reopens it here.
  protected readonly editingId = signal<number | null>(null);

  // right-click-to-add menu: screenX/screenY position the menu itself
  // (viewport coordinates, since it's a position:fixed element); left/top
  // are the same spot converted to canvas-pixel space, used to place
  // whichever item gets added from it.
  protected readonly contextMenu = signal<{
    screenX: number;
    screenY: number;
    left: number;
    top: number;
  } | null>(null);

  @HostListener('document:click')
  onDocumentClick(): void {
    this.editingId.set(null);
    this.contextMenu.set(null);
  }

  @HostListener('document:keydown.escape')
  onEscapeKey(): void {
    this.contextMenu.set(null);
  }

  private nextId = 1;
  private draggingId: number | null = null;
  private resizingId: number | null = null;

  async onFileSelected(event: Event): Promise<void> {
    const input = event.target as HTMLInputElement;
    const file = input.files?.[0];
    if (!file) return;

    this.fileBytes = new Uint8Array(await file.arrayBuffer());
    this.overlaysByPage.set(new Map());
    this.currentItems.set([]);
    this.editingId.set(null);
    this.contextMenu.set(null);

    const pdf = await pdfjsLib.getDocument({ data: this.fileBytes.slice() }).promise;
    this.pageCount.set(pdf.numPages);
    this.currentPage.set(1);
    // <canvas #pdfCanvas> only exists once pageCount() > 0 gates it into the
    // template, and that signal write hasn't flushed to the DOM yet at this
    // point — calling renderPage() immediately would find canvasRef()
    // undefined and silently no-op. afterNextRender waits for that flush.
    afterNextRender(() => void this.renderPage(1), { injector: this.injector });
  }

  private async renderPage(pageNum: number): Promise<void> {
    if (!this.fileBytes) return;
    const canvas = this.canvasRef()?.nativeElement;
    if (!canvas) return;

    const pdf = await pdfjsLib.getDocument({ data: this.fileBytes.slice() }).promise;
    const page = await pdf.getPage(pageNum);
    const viewport = page.getViewport({ scale: this.scale });
    this.canvasWidth.set(viewport.width);
    this.canvasHeight.set(viewport.height);

    canvas.width = viewport.width;
    canvas.height = viewport.height;
    const context = canvas.getContext('2d')!;
    await page.render({ canvasContext: context, viewport, canvas }).promise;

    this.currentItems.set(this.overlaysByPage().get(pageNum) ?? []);
  }

  private setCurrentItems(items: OverlayItem[]): void {
    const map = new Map(this.overlaysByPage());
    map.set(this.currentPage(), items);
    this.overlaysByPage.set(map);
    this.currentItems.set(items);
  }

  protected readonly stampPresets = STAMP_PRESETS;
  protected readonly stampRotationDeg = STAMP_ROTATION_DEG;
  protected readonly signaturePresets = SIGNATURE_PRESETS;
  protected readonly approxAscentForEditingInput = APPROX_ASCENT_FOR_EDITING_INPUT;
  protected readonly strikethroughThicknessPt = STRIKETHROUGH_THICKNESS_PT;

  private measureCanvas: HTMLCanvasElement | null = null;

  /** Width, in px, that fits the item's current text exactly — measured
   * with the same font stack it's rendered in, so the input grows/shrinks
   * with what's actually typed instead of sitting at some arbitrary fixed
   * width regardless of content. */
  protected textInputWidth(item: OverlayItem): number {
    if (!this.measureCanvas) this.measureCanvas = document.createElement('canvas');
    const ctx = this.measureCanvas.getContext('2d')!;
    ctx.font = `${item.fontSize * this.scale}px Helvetica, Arial, sans-serif`;
    const textWidth = ctx.measureText(item.text || ' ').width;
    return Math.max(textWidth + 12, 24);
  }

  /** Vertical position of the drag/remove/resize chrome row, in px above
   * item.top. For text/stamp, content grows UPWARD from the baseline as
   * font size increases, so the chrome must rise with it or a big enough
   * font pushes the text up over the buttons, covering them. Checkbox and
   * signature content grows DOWNWARD from item.top instead, so a fixed gap
   * is enough regardless of size. */
  protected chromeRowTop(item: OverlayItem): number {
    if (item.kind === 'text' || item.kind === 'stamp') {
      return -(item.fontSize * this.scale * this.approxAscentForEditingInput) - 26;
    }
    return -26;
  }

  onCanvasContextMenu(event: MouseEvent): void {
    event.preventDefault();
    const canvas = this.canvasRef()?.nativeElement;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    this.contextMenu.set({
      screenX: event.clientX,
      screenY: event.clientY,
      left: event.clientX - rect.left,
      top: event.clientY - rect.top,
    });
  }

  /** Handles a click on one of the right-click menu's options: adds the
   * chosen item kind at the position the menu was opened at, then closes
   * the menu. stopPropagation keeps the same click from also reaching
   * onDocumentClick, which would otherwise immediately deselect the item
   * this just put into edit mode. */
  onAddFromMenu(kind: 'text' | 'date' | 'checkbox' | 'strikethrough', event: MouseEvent): void {
    event.stopPropagation();
    const menu = this.contextMenu();
    if (!menu) return;
    this.contextMenu.set(null);

    if (kind === 'text') this.addTextItem(menu.left, menu.top);
    else if (kind === 'date') this.addDateItem(menu.left, menu.top);
    else if (kind === 'checkbox') this.addCheckboxItem(menu.left, menu.top);
    else if (kind === 'strikethrough') this.addStrikethroughItem(menu.left, menu.top);
  }

  onAddStampFromMenu(preset: StampPreset, event: MouseEvent): void {
    event.stopPropagation();
    const menu = this.contextMenu();
    if (!menu) return;
    this.contextMenu.set(null);
    this.addStampItem(preset, menu.left, menu.top);
  }

  onAddSignatureFromMenu(preset: SignaturePreset, event: MouseEvent): void {
    event.stopPropagation();
    const menu = this.contextMenu();
    if (!menu) return;
    this.contextMenu.set(null);
    void this.addSignatureItem(preset, menu.left, menu.top);
  }

  addTextItem(left = 40, top = 60): void {
    const id = this.nextId++;
    // top is this item's baseline — default start a bit down so the
    // glyphs' ascent isn't clipped above the page edge.
    const item: OverlayItem = { id, left, top, kind: 'text', text: 'New text', fontSize: 16 };
    this.setCurrentItems([...this.currentItems(), item]);
    this.editingId.set(id);
  }

  addDateItem(left = 40, top = 60): void {
    const id = this.nextId++;
    const today = new Date().toISOString().slice(0, 10);
    const item: OverlayItem = { id, left, top, kind: 'text', text: today, fontSize: 14 };
    this.setCurrentItems([...this.currentItems(), item]);
    this.editingId.set(id);
  }

  addCheckboxItem(left = 40, top = 40): void {
    const id = this.nextId++;
    const item: OverlayItem = {
      id,
      left,
      top,
      kind: 'checkbox',
      text: '',
      fontSize: 0,
      checked: false,
      checkboxSize: 14,
    };
    this.setCurrentItems([...this.currentItems(), item]);
    this.editingId.set(id);
  }

  toggleCheckbox(id: number): void {
    this.setCurrentItems(
      this.currentItems().map((i) => (i.id === id ? { ...i, checked: !i.checked } : i)),
    );
  }

  addStampItem(preset: StampPreset, left = 80, top = 130): void {
    const id = this.nextId++;
    const item: OverlayItem = {
      id,
      left,
      top,
      kind: 'stamp',
      text: preset.label,
      fontSize: 28,
      stampColor: preset.pdfColor,
      stampCssColor: preset.cssColor,
    };
    this.setCurrentItems([...this.currentItems(), item]);
    this.editingId.set(id);
  }

  addStrikethroughItem(left = 40, top = 40): void {
    const id = this.nextId++;
    const item: OverlayItem = { id, left, top, kind: 'strikethrough', text: '', fontSize: 0, strikeWidth: 100 };
    this.setCurrentItems([...this.currentItems(), item]);
    this.editingId.set(id);
  }

  updateItemText(id: number, text: string): void {
    this.setCurrentItems(this.currentItems().map((i) => (i.id === id ? { ...i, text } : i)));
  }

  removeItem(id: number): void {
    this.setCurrentItems(this.currentItems().filter((i) => i.id !== id));
    if (this.editingId() === id) this.editingId.set(null);
  }

  startDrag(id: number, event: MouseEvent): void {
    event.preventDefault();
    this.draggingId = id;
  }

  startResize(id: number, event: MouseEvent): void {
    event.preventDefault();
    this.resizingId = id;
  }

  @HostListener('window:mousemove', ['$event'])
  onWindowMouseMove(event: MouseEvent): void {
    if (this.draggingId !== null) {
      const id = this.draggingId;
      this.setCurrentItems(
        this.currentItems().map((i) =>
          i.id === id ? { ...i, left: i.left + event.movementX, top: i.top + event.movementY } : i,
        ),
      );
    } else if (this.resizingId !== null) {
      const id = this.resizingId;
      // dragging down/right grows the item, up/left shrinks it
      const delta = event.movementX + event.movementY;
      this.setCurrentItems(
        this.currentItems().map((i) => {
          if (i.id !== id) return i;
          if (i.kind === 'signature' && i.imgWidth && i.imgHeight) {
            const aspect = i.imgHeight / i.imgWidth;
            const imgWidth = Math.max(20, i.imgWidth + delta);
            return { ...i, imgWidth, imgHeight: imgWidth * aspect };
          }
          if (i.kind === 'text' || i.kind === 'stamp') {
            const fontSize = Math.max(6, Math.min(200, i.fontSize + delta * 0.5));
            return { ...i, fontSize };
          }
          if (i.kind === 'checkbox') {
            const checkboxSize = Math.max(8, Math.min(100, (i.checkboxSize ?? 14) + delta * 0.5));
            return { ...i, checkboxSize };
          }
          if (i.kind === 'strikethrough') {
            // Width-only growth — thickness is a fixed constant, never
            // resized, so this never touches fontSize.
            const strikeWidth = Math.max(20, (i.strikeWidth ?? 100) + delta);
            return { ...i, strikeWidth };
          }
          return i;
        }),
      );
    }
  }

  @HostListener('window:mouseup')
  onWindowMouseUp(): void {
    this.draggingId = null;
    this.resizingId = null;
  }

  async prevPage(): Promise<void> {
    if (this.currentPage() <= 1) return;
    this.currentPage.update((p) => p - 1);
    this.editingId.set(null);
    this.contextMenu.set(null);
    await this.renderPage(this.currentPage());
  }

  async nextPage(): Promise<void> {
    if (this.currentPage() >= this.pageCount()) return;
    this.currentPage.update((p) => p + 1);
    this.editingId.set(null);
    this.contextMenu.set(null);
    await this.renderPage(this.currentPage());
  }

  /** Loads a signature preset's source GIF and re-encodes it as a PNG data
   * URL — pdf-lib can embedPng/embedJpg but has no embedGif, so GIFs must be
   * flattened via canvas before previewPdf() can draw them into the PDF. */
  private loadSignatureAsPng(path: string): Promise<{ dataUrl: string; width: number; height: number }> {
    return new Promise((resolve, reject) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        canvas.width = img.naturalWidth;
        canvas.height = img.naturalHeight;
        canvas.getContext('2d')!.drawImage(img, 0, 0);
        resolve({ dataUrl: canvas.toDataURL('image/png'), width: img.naturalWidth, height: img.naturalHeight });
      };
      img.onerror = () => reject(new Error(`Failed to load signature image: ${path}`));
      img.src = path;
    });
  }

  async addSignatureItem(preset: SignaturePreset, left = 40, top = 40): Promise<void> {
    const { dataUrl, width, height } = await this.loadSignatureAsPng(preset.path);
    const displayScale = width > SIGNATURE_MAX_INITIAL_WIDTH ? SIGNATURE_MAX_INITIAL_WIDTH / width : 1;

    const id = this.nextId++;
    const item: OverlayItem = {
      id,
      left,
      top,
      kind: 'signature',
      text: '',
      fontSize: 0,
      imageDataUrl: dataUrl,
      imgWidth: width * displayScale,
      imgHeight: height * displayScale,
    };
    this.setCurrentItems([...this.currentItems(), item]);
    this.editingId.set(id);
  }

  async previewPdf(): Promise<void> {
    if (!this.fileBytes) return;

    const pdfDoc = await PDFDocument.load(this.fileBytes);
    const font = await pdfDoc.embedFont(StandardFonts.Helvetica);
    const boldFont = await pdfDoc.embedFont(StandardFonts.HelveticaBold);
    const pages = pdfDoc.getPages();

    for (const [pageNum, items] of this.overlaysByPage()) {
      const page = pages[pageNum - 1];
      if (!page || items.length === 0) continue;
      const pageHeightPt = page.getHeight();

      for (const item of items) {
        const x = item.left / this.scale;
        // For text/stamp, item.top IS the baseline already — the same
        // point drawText expects — so no font-metric guessing is needed
        // here at all (that guessing is exactly what caused the drift).
        // For checkbox/signature, item.top is the visual top of the box.
        const y = pageHeightPt - item.top / this.scale;

        if (item.kind === 'text') {
          if (!item.text.trim()) continue;
          page.drawText(item.text, { x, y, size: item.fontSize, font, color: rgb(0, 0, 0) });
        } else if (item.kind === 'signature' && item.imageDataUrl) {
          const png = await pdfDoc.embedPng(item.imageDataUrl);
          const width = (item.imgWidth ?? png.width) / this.scale;
          const height = (item.imgHeight ?? png.height) / this.scale;
          page.drawImage(png, { x, y: y - height, width, height });
        } else if (item.kind === 'checkbox') {
          const size = item.checkboxSize ?? 14;
          const bottom = y - size;
          page.drawRectangle({
            x,
            y: bottom,
            width: size,
            height: size,
            borderColor: rgb(0.6, 0.6, 0.6),
            borderWidth: 1,
            color: item.checked ? rgb(0.1, 0.54, 0.24) : undefined,
          });
          if (item.checked) {
            // A drawn checkmark, not a glyph — WinAnsi (what StandardFonts
            // uses) has no ✓ character, and this looks like a real checkbox.
            const p1 = { x: x + size * 0.2, y: bottom + size * 0.5 };
            const p2 = { x: x + size * 0.42, y: bottom + size * 0.22 };
            const p3 = { x: x + size * 0.8, y: bottom + size * 0.75 };
            page.drawLine({ start: p1, end: p2, thickness: 1.6, color: rgb(1, 1, 1) });
            page.drawLine({ start: p2, end: p3, thickness: 1.6, color: rgb(1, 1, 1) });
          }
        } else if (item.kind === 'stamp') {
          page.drawText(item.text, {
            x,
            y,
            size: item.fontSize,
            font: boldFont,
            color: item.stampColor ?? rgb(0, 0, 0),
            rotate: degrees(STAMP_ROTATION_DEG),
            opacity: 0.55,
          });
        } else if (item.kind === 'strikethrough') {
          const width = item.strikeWidth ?? 100;
          page.drawLine({
            start: { x, y },
            end: { x: x + width, y },
            thickness: STRIKETHROUGH_THICKNESS_PT,
            color: rgb(0, 0, 0),
          });
        }
      }
    }

    const bytes = await pdfDoc.save();
    const blob = new Blob([bytes.slice()], { type: 'application/pdf' });
    const url = URL.createObjectURL(blob);
    window.open(url, '_blank');
    // Revoking immediately (as a download's <a> click allows) would break
    // this: the new tab needs time to actually fetch the blob URL before
    // it renders, so free it later instead.
    setTimeout(() => URL.revokeObjectURL(url), 60000);
  }
}
