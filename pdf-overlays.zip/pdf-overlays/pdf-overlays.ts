import { Component, ElementRef, HostListener, signal, viewChild } from '@angular/core';
import { PDFDocument, RGB, StandardFonts, degrees, rgb } from 'pdf-lib';
import * as pdfjsLib from 'pdfjs-dist';

pdfjsLib.GlobalWorkerOptions.workerSrc = '/pdf.worker.min.mjs';

export interface StampPreset {
  label: string;
  cssColor: string;
  pdfColor: RGB;
}

export const STAMP_PRESETS: StampPreset[] = [
  { label: 'APPROVED', cssColor: '#1a8a3c', pdfColor: rgb(0.1, 0.54, 0.24) },
  { label: 'REJECTED', cssColor: '#c0392b', pdfColor: rgb(0.75, 0.22, 0.17) },
  { label: 'CONFIDENTIAL', cssColor: '#a35b00', pdfColor: rgb(0.64, 0.36, 0) },
  { label: 'DRAFT', cssColor: '#666', pdfColor: rgb(0.4, 0.4, 0.4) },
];

// Rough visual offset used ONLY to position the editing <input> reasonably
// while typing (an <input> can't be baseline-aligned like SVG text can).
// It's purely cosmetic — item.top itself is the baseline, used directly and
// exactly by both the locked SVG preview and download(), so this constant
// being approximate never affects the exported result.
const APPROX_ASCENT_FOR_EDITING_INPUT = 0.7;

// Rotation conventions are opposite between the two coordinate systems:
// PDF y-axis points up (positive degrees = counter-clockwise), CSS y-axis
// points down (positive degrees = clockwise). Same magnitude, opposite sign,
// gives the same visual tilt on screen and in the exported PDF.
const STAMP_ROTATION_DEG = -20;

interface OverlayItem {
  id: number;
  left: number;
  top: number;
  kind: 'text' | 'signature' | 'checkbox' | 'stamp';
  text: string;
  fontSize: number;
  imageDataUrl?: string;
  imgWidth?: number;
  imgHeight?: number;
  checked?: boolean;
  checkboxSize?: number;
  stampColor?: RGB;
  stampCssColor?: string;
}

// PDF libraries used here: pdf-lib builds the exported PDF (drawText,
// drawRectangle, drawLine, drawImage, embedPng, embedFont), and pdfjs-dist
// renders the loaded PDF's pages to canvas for the on-screen preview.
// package.json: "pdf-lib": "^1.17.1", "pdfjs-dist": "^6.2.108"
@Component({
  selector: 'app-pdf-overlays',
  imports: [],
  templateUrl: './pdf-overlays.html',
  styleUrl: './pdf-overlays.css',
})
export class PdfOverlays {
  private readonly canvasRef = viewChild<ElementRef<HTMLCanvasElement>>('pdfCanvas');
  private readonly sigCanvasRef = viewChild<ElementRef<HTMLCanvasElement>>('sigCanvas');

  protected readonly pageCount = signal(0);
  protected readonly currentPage = signal(1);
  protected readonly canvasWidth = signal(0);
  protected readonly canvasHeight = signal(0);
  protected readonly showSignaturePad = signal(false);

  protected readonly scale = 1.5;
  private fileBytes: Uint8Array | null = null;

  private readonly overlaysByPage = signal<Map<number, OverlayItem[]>>(new Map());
  protected readonly currentItems = signal<OverlayItem[]>([]);
  // the one item currently showing its editing chrome (drag handle, inputs,
  // remove button); every other item renders as plain, final-looking
  // content. Clicking anywhere outside it applies/locks it; double-clicking
  // a locked item's content reopens it here.
  protected readonly editingId = signal<number | null>(null);

  // right-click-to-add menu: screenX/screenY position the menu itself
  // (viewport coordinates, since it's a position:fixed element); left/top
  // are the same spot converted to canvas-pixel space, used to place
  // whichever item gets added from it.
  protected readonly contextMenu = signal<{
    screenX: number;
    screenY: number;
    left: number;
    top: number;
  } | null>(null);

  @HostListener('document:click')
  onDocumentClick(): void {
    this.editingId.set(null);
    this.contextMenu.set(null);
  }

  @HostListener('document:keydown.escape')
  onEscapeKey(): void {
    this.contextMenu.set(null);
  }

  private nextId = 1;
  private draggingId: number | null = null;
  private resizingId: number | null = null;
  private isDrawingSignature = false;
  private lastPoint: { x: number; y: number } | null = null;
  // where the signature pad's "Save" should place its item — set when the
  // pad is opened from the right-click menu, so the signature lands where
  // you right-clicked instead of always at a fixed default spot.
  private pendingSignaturePos: { left: number; top: number } | null = null;
  // where the signature pad ITSELF appears on screen — the same spot the
  // right-click menu was opened at, so it shows up under the mouse instead
  // of a fixed spot elsewhere on the page.
  protected readonly signaturePadPos = signal<{ x: number; y: number } | null>(null);

  async onFileSelected(event: Event): Promise<void> {
    const input = event.target as HTMLInputElement;
    const file = input.files?.[0];
    if (!file) return;

    this.fileBytes = new Uint8Array(await file.arrayBuffer());
    this.overlaysByPage.set(new Map());
    this.currentItems.set([]);
    this.editingId.set(null);
    this.contextMenu.set(null);
    this.signaturePadPos.set(null);
    this.showSignaturePad.set(false);

    const pdf = await pdfjsLib.getDocument({ data: this.fileBytes.slice() }).promise;
    this.pageCount.set(pdf.numPages);
    this.currentPage.set(1);
    await this.renderPage(1);
  }

  private async renderPage(pageNum: number): Promise<void> {
    if (!this.fileBytes) return;
    const canvas = this.canvasRef()?.nativeElement;
    if (!canvas) return;

    const pdf = await pdfjsLib.getDocument({ data: this.fileBytes.slice() }).promise;
    const page = await pdf.getPage(pageNum);
    const viewport = page.getViewport({ scale: this.scale });
    this.canvasWidth.set(viewport.width);
    this.canvasHeight.set(viewport.height);

    canvas.width = viewport.width;
    canvas.height = viewport.height;
    const context = canvas.getContext('2d')!;
    await page.render({ canvasContext: context, viewport, canvas }).promise;

    this.currentItems.set(this.overlaysByPage().get(pageNum) ?? []);
  }

  private setCurrentItems(items: OverlayItem[]): void {
    const map = new Map(this.overlaysByPage());
    map.set(this.currentPage(), items);
    this.overlaysByPage.set(map);
    this.currentItems.set(items);
  }

  protected readonly stampPresets = STAMP_PRESETS;
  protected readonly stampRotationDeg = STAMP_ROTATION_DEG;
  protected readonly approxAscentForEditingInput = APPROX_ASCENT_FOR_EDITING_INPUT;

  private measureCanvas: HTMLCanvasElement | null = null;

  /** Width, in px, that fits the item's current text exactly — measured
   * with the same font stack it's rendered in, so the input grows/shrinks
   * with what's actually typed instead of sitting at some arbitrary fixed
   * width regardless of content. */
  protected textInputWidth(item: OverlayItem): number {
    if (!this.measureCanvas) this.measureCanvas = document.createElement('canvas');
    const ctx = this.measureCanvas.getContext('2d')!;
    ctx.font = `${item.fontSize * this.scale}px Helvetica, Arial, sans-serif`;
    const textWidth = ctx.measureText(item.text || ' ').width;
    return Math.max(textWidth + 12, 24);
  }

  /** Vertical position of the drag/remove/resize chrome row, in px above
   * item.top. For text/stamp, content grows UPWARD from the baseline as
   * font size increases, so the chrome must rise with it or a big enough
   * font pushes the text up over the buttons, covering them. Checkbox and
   * signature content grows DOWNWARD from item.top instead, so a fixed gap
   * is enough regardless of size. */
  protected chromeRowTop(item: OverlayItem): number {
    if (item.kind === 'text' || item.kind === 'stamp') {
      return -(item.fontSize * this.scale * this.approxAscentForEditingInput) - 26;
    }
    return -26;
  }

  onCanvasContextMenu(event: MouseEvent): void {
    event.preventDefault();
    const canvas = this.canvasRef()?.nativeElement;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    this.contextMenu.set({
      screenX: event.clientX,
      screenY: event.clientY,
      left: event.clientX - rect.left,
      top: event.clientY - rect.top,
    });
  }

  /** Handles a click on one of the right-click menu's options: adds the
   * chosen item kind at the position the menu was opened at, then closes
   * the menu. stopPropagation keeps the same click from also reaching
   * onDocumentClick, which would otherwise immediately deselect the item
   * this just put into edit mode. */
  onAddFromMenu(kind: 'text' | 'date' | 'checkbox' | 'signature', event: MouseEvent): void {
    event.stopPropagation();
    const menu = this.contextMenu();
    if (!menu) return;
    this.contextMenu.set(null);

    if (kind === 'text') this.addTextItem(menu.left, menu.top);
    else if (kind === 'date') this.addDateItem(menu.left, menu.top);
    else if (kind === 'checkbox') this.addCheckboxItem(menu.left, menu.top);
    else if (kind === 'signature') this.openSignaturePadAt(menu.left, menu.top, menu.screenX, menu.screenY);
  }

  onAddStampFromMenu(preset: StampPreset, event: MouseEvent): void {
    event.stopPropagation();
    const menu = this.contextMenu();
    if (!menu) return;
    this.contextMenu.set(null);
    this.addStampItem(preset, menu.left, menu.top);
  }

  addTextItem(left = 40, top = 60): void {
    const id = this.nextId++;
    // top is this item's baseline — default start a bit down so the
    // glyphs' ascent isn't clipped above the page edge.
    const item: OverlayItem = { id, left, top, kind: 'text', text: 'New text', fontSize: 16 };
    this.setCurrentItems([...this.currentItems(), item]);
    this.editingId.set(id);
  }

  addDateItem(left = 40, top = 60): void {
    const id = this.nextId++;
    const today = new Date().toISOString().slice(0, 10);
    const item: OverlayItem = { id, left, top, kind: 'text', text: today, fontSize: 14 };
    this.setCurrentItems([...this.currentItems(), item]);
    this.editingId.set(id);
  }

  addCheckboxItem(left = 40, top = 40): void {
    const id = this.nextId++;
    const item: OverlayItem = {
      id,
      left,
      top,
      kind: 'checkbox',
      text: '',
      fontSize: 0,
      checked: false,
      checkboxSize: 14,
    };
    this.setCurrentItems([...this.currentItems(), item]);
    this.editingId.set(id);
  }

  toggleCheckbox(id: number): void {
    this.setCurrentItems(
      this.currentItems().map((i) => (i.id === id ? { ...i, checked: !i.checked } : i)),
    );
  }

  addStampItem(preset: StampPreset, left = 80, top = 130): void {
    const id = this.nextId++;
    const item: OverlayItem = {
      id,
      left,
      top,
      kind: 'stamp',
      text: preset.label,
      fontSize: 28,
      stampColor: preset.pdfColor,
      stampCssColor: preset.cssColor,
    };
    this.setCurrentItems([...this.currentItems(), item]);
    this.editingId.set(id);
  }

  updateItemText(id: number, text: string): void {
    this.setCurrentItems(this.currentItems().map((i) => (i.id === id ? { ...i, text } : i)));
  }

  removeItem(id: number): void {
    this.setCurrentItems(this.currentItems().filter((i) => i.id !== id));
    if (this.editingId() === id) this.editingId.set(null);
  }

  startDrag(id: number, event: MouseEvent): void {
    event.preventDefault();
    this.draggingId = id;
  }

  startResize(id: number, event: MouseEvent): void {
    event.preventDefault();
    this.resizingId = id;
  }

  @HostListener('window:mousemove', ['$event'])
  onWindowMouseMove(event: MouseEvent): void {
    if (this.draggingId !== null) {
      const id = this.draggingId;
      this.setCurrentItems(
        this.currentItems().map((i) =>
          i.id === id ? { ...i, left: i.left + event.movementX, top: i.top + event.movementY } : i,
        ),
      );
    } else if (this.resizingId !== null) {
      const id = this.resizingId;
      // dragging down/right grows the item, up/left shrinks it
      const delta = event.movementX + event.movementY;
      this.setCurrentItems(
        this.currentItems().map((i) => {
          if (i.id !== id) return i;
          if (i.kind === 'signature' && i.imgWidth && i.imgHeight) {
            const aspect = i.imgHeight / i.imgWidth;
            const imgWidth = Math.max(20, i.imgWidth + delta);
            return { ...i, imgWidth, imgHeight: imgWidth * aspect };
          }
          if (i.kind === 'text' || i.kind === 'stamp') {
            const fontSize = Math.max(6, Math.min(200, i.fontSize + delta * 0.5));
            return { ...i, fontSize };
          }
          if (i.kind === 'checkbox') {
            const checkboxSize = Math.max(8, Math.min(100, (i.checkboxSize ?? 14) + delta * 0.5));
            return { ...i, checkboxSize };
          }
          return i;
        }),
      );
    }
  }

  @HostListener('window:mouseup')
  onWindowMouseUp(): void {
    this.draggingId = null;
    this.resizingId = null;
  }

  async prevPage(): Promise<void> {
    if (this.currentPage() <= 1) return;
    this.currentPage.update((p) => p - 1);
    this.editingId.set(null);
    this.contextMenu.set(null);
    await this.renderPage(this.currentPage());
  }

  async nextPage(): Promise<void> {
    if (this.currentPage() >= this.pageCount()) return;
    this.currentPage.update((p) => p + 1);
    this.editingId.set(null);
    this.contextMenu.set(null);
    await this.renderPage(this.currentPage());
  }

  /** left/top (canvas-pixel space) are where the finished signature item
   * will be placed; screenX/screenY (viewport space) are where the pad
   * itself appears — both come from the same right-click, so the pad shows
   * up right under the mouse instead of a fixed spot elsewhere on the page. */
  openSignaturePadAt(left: number, top: number, screenX: number, screenY: number): void {
    this.pendingSignaturePos = { left, top };
    this.signaturePadPos.set({ x: screenX, y: screenY });
    this.showSignaturePad.set(true);
    setTimeout(() => this.clearSignaturePad());
  }

  closeSignaturePad(): void {
    this.pendingSignaturePos = null;
    this.signaturePadPos.set(null);
    this.showSignaturePad.set(false);
  }

  clearSignaturePad(): void {
    const canvas = this.sigCanvasRef()?.nativeElement;
    if (!canvas) return;
    const ctx = canvas.getContext('2d')!;
    ctx.fillStyle = '#fff';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.strokeStyle = '#000';
    ctx.lineWidth = 2;
    ctx.lineCap = 'round';
  }

  startSignatureStroke(event: MouseEvent): void {
    this.isDrawingSignature = true;
    this.lastPoint = this.signatureEventPoint(event);
  }

  drawSignatureStroke(event: MouseEvent): void {
    if (!this.isDrawingSignature) return;
    const canvas = this.sigCanvasRef()?.nativeElement;
    if (!canvas) return;
    const ctx = canvas.getContext('2d')!;
    const point = this.signatureEventPoint(event);
    if (this.lastPoint) {
      ctx.beginPath();
      ctx.moveTo(this.lastPoint.x, this.lastPoint.y);
      ctx.lineTo(point.x, point.y);
      ctx.stroke();
    }
    this.lastPoint = point;
  }

  endSignatureStroke(): void {
    this.isDrawingSignature = false;
    this.lastPoint = null;
  }

  private signatureEventPoint(event: MouseEvent): { x: number; y: number } {
    const canvas = this.sigCanvasRef()!.nativeElement;
    const rect = canvas.getBoundingClientRect();
    return { x: event.clientX - rect.left, y: event.clientY - rect.top };
  }

  saveSignature(): void {
    const canvas = this.sigCanvasRef()?.nativeElement;
    if (!canvas) return;

    const id = this.nextId++;
    const pos = this.pendingSignaturePos ?? { left: 40, top: 40 };
    this.pendingSignaturePos = null;
    const item: OverlayItem = {
      id,
      left: pos.left,
      top: pos.top,
      kind: 'signature',
      text: '',
      fontSize: 0,
      imageDataUrl: canvas.toDataURL('image/png'),
      imgWidth: canvas.width,
      imgHeight: canvas.height,
    };
    this.setCurrentItems([...this.currentItems(), item]);
    this.editingId.set(id);
    this.signaturePadPos.set(null);
    this.showSignaturePad.set(false);
  }

  async previewPdf(): Promise<void> {
    if (!this.fileBytes) return;

    const pdfDoc = await PDFDocument.load(this.fileBytes);
    const font = await pdfDoc.embedFont(StandardFonts.Helvetica);
    const boldFont = await pdfDoc.embedFont(StandardFonts.HelveticaBold);
    const pages = pdfDoc.getPages();

    for (const [pageNum, items] of this.overlaysByPage()) {
      const page = pages[pageNum - 1];
      if (!page || items.length === 0) continue;
      const pageHeightPt = page.getHeight();

      for (const item of items) {
        const x = item.left / this.scale;
        // For text/stamp, item.top IS the baseline already — the same
        // point drawText expects — so no font-metric guessing is needed
        // here at all (that guessing is exactly what caused the drift).
        // For checkbox/signature, item.top is the visual top of the box.
        const y = pageHeightPt - item.top / this.scale;

        if (item.kind === 'text') {
          if (!item.text.trim()) continue;
          page.drawText(item.text, { x, y, size: item.fontSize, font, color: rgb(0, 0, 0) });
        } else if (item.kind === 'signature' && item.imageDataUrl) {
          const png = await pdfDoc.embedPng(item.imageDataUrl);
          const width = (item.imgWidth ?? png.width) / this.scale;
          const height = (item.imgHeight ?? png.height) / this.scale;
          page.drawImage(png, { x, y: y - height, width, height });
        } else if (item.kind === 'checkbox') {
          const size = item.checkboxSize ?? 14;
          const bottom = y - size;
          page.drawRectangle({
            x,
            y: bottom,
            width: size,
            height: size,
            borderColor: rgb(0.6, 0.6, 0.6),
            borderWidth: 1,
            color: item.checked ? rgb(0.1, 0.54, 0.24) : undefined,
          });
          if (item.checked) {
            // A drawn checkmark, not a glyph — WinAnsi (what StandardFonts
            // uses) has no ✓ character, and this looks like a real checkbox.
            const p1 = { x: x + size * 0.2, y: bottom + size * 0.5 };
            const p2 = { x: x + size * 0.42, y: bottom + size * 0.22 };
            const p3 = { x: x + size * 0.8, y: bottom + size * 0.75 };
            page.drawLine({ start: p1, end: p2, thickness: 1.6, color: rgb(1, 1, 1) });
            page.drawLine({ start: p2, end: p3, thickness: 1.6, color: rgb(1, 1, 1) });
          }
        } else if (item.kind === 'stamp') {
          page.drawText(item.text, {
            x,
            y,
            size: item.fontSize,
            font: boldFont,
            color: item.stampColor ?? rgb(0, 0, 0),
            rotate: degrees(STAMP_ROTATION_DEG),
            opacity: 0.55,
          });
        }
      }
    }

    const bytes = await pdfDoc.save();
    const blob = new Blob([bytes.slice()], { type: 'application/pdf' });
    const url = URL.createObjectURL(blob);
    window.open(url, '_blank');
    // Revoking immediately (as a download's <a> click allows) would break
    // this: the new tab needs time to actually fetch the blob URL before
    // it renders, so free it later instead.
    setTimeout(() => URL.revokeObjectURL(url), 60000);
  }
}
